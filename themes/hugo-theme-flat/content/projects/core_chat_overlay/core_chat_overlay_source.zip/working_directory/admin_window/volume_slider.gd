extends HSlider

func _ready():
	value_changed.connect(_on_value_changed)
	set_value_no_signal(ConfigManager.get_setting("basic", "tts_volume"))

func _on_value_changed(new_value):
	ConfigManager.set_setting("basic", "tts_volume", new_value)

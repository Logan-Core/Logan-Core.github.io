extends Control
class_name EmoteControl

var frames: SpriteFrames
var emote_scale: float = 1.0

var _sprite: AnimatedSprite2D


func _ready():
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	_sprite = AnimatedSprite2D.new()
	add_child(_sprite)

	_sprite.frames = frames
	_sprite.scale = Vector2(emote_scale, emote_scale)

	if frames:
		var tex := frames.get_frame_texture("default", 0)
		if tex:
			custom_minimum_size = Vector2(32.0,32.0)


func restart():
	if _sprite:
		_sprite.frame = 0
		_sprite.play("default")


# useless for now with hardcoded size but may be needed in future for possible updates
func _notification(what: int):
	if what == NOTIFICATION_RESIZED and _sprite:
		_sprite.position = size * 0.5

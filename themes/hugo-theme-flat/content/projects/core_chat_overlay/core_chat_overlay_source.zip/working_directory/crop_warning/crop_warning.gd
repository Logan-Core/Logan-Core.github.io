extends Control


func _input(_event):
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		var remove_tween = create_tween()
		remove_tween.tween_property(self, "modulate", Color.TRANSPARENT, 0.4)
		remove_tween.tween_callback(queue_free)


func _ready():
	if ConfigManager.get_setting("basic", "skip_obs_crop_warning"):
		queue_free()

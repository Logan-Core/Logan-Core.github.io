extends Node


var is_archive_mode: bool = false

func _input(_event):
	if Input.is_key_label_pressed(KEY_F1) and Input.is_key_label_pressed(KEY_ESCAPE):
		quit()

func _ready():
	get_tree().root.close_requested.connect(quit)


func get_program_path() -> String:
	return "user://" if OS.has_feature("editor") else OS.get_executable_path().get_base_dir()

# DisplayServer tts runs separate from teh main Godot application. Kill it before closing out Godot or tts server will continue speaking
func quit():
	DisplayServer.tts_stop()
	get_tree().quit()

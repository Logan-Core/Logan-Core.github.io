Configuring the overlay:
Twitch Authentication Settings:
	Get these from the Twitch developer portal:
		https://dev.twitch.tv/
		Create an Application:
			Name = "put_anything_here"
			OAuth Redirect URLs ='http://localhost:7170'
			Category = 'Chat Bot'
			Client Type = 'Confidential'

		After registering the application, Copy the client ID and fill out the [client_auth] settings of the config with the information Twitch provides.
		broadcaster_username and bot_username can be the same user if desired. Just make sure you are signed into whatever account you have assigned as the bot when authenticating the overlay



Basic Settings:
	skip_obs_crop_warning:
		Stops the green/red pop up when launching the program
	prevent_bot_message_tts:
		All messages sent via the bot are ignored by TTS (Not very useful yet. Could come in handy if overlay gets extended and new commands gets added)
	magick_path:
		Download and install ImageMagick from https://imagemagick.org/
		The overlay will fallback to a built-in image transformer without it, however, animated gifs will not play correctly (Previous frames in transparent gifs won't clear/etc)
		Update the config to point to the ImageMagick exe
	censor_images_until_approved:
		Do yourself a favor and leave this on. A chatter can easily abuse this and put some nasty stuff on the stream otherwise.



Using the Core Chat Overlay:
	1. If you make any changes to the client authentication settings, relaunch the program
	2. Click the "AUTH URL" button from the admin panel to copy the authorization URL to the clipboard
	3. If using a bot account, make sure you're logged into it (use an incognito browser if you want to stay logged into your main account)
	4. Paste the URL into your webbrowser which is logged into whatever account you assigned as your "bot_username" in the config.
	5. Click the authorize button and you're set! (It can take some time for the overlay to connect. Give it a minute before panicking)

	After a user sends a message in chat, their profile image will be fetched and cached into the overlay.
	They will be censored by default until you manually approve them in the admin panel by pressing the "GOOD" button or you can send it to the back of the queue by pressing "BAD"

	Global hotkeys are not supported so a workaround I implemented is setting up a basic UDP listener server which you can ping with specific strings to activate admin panel buttons even while gaming
	The following commands are available:
	"approve_image":
	"deny_image":
	"skip_chatter":

	On windows, the command to enter looks like this:
		echo approve_image | ncat -u 127.0.0.1 5555
	ncat isn't installed by default. You'll have to setup that manually.
	Download the nmap installer from https://nmap.org/download.html#windows
	and make sure the ncat utility is installed and added to your PATH during setup.
	After that's done, create some global shortcuts in Windows to execute these commands and then you can approve/deny images without having to alt tab out of games.



	Optional YouTube Live setup:
	1. After going live on YouTube, copy the video id of your stream from the livestream page to your clipboard.
	2. Run the "youtube_live_listener.py" file from a terminal using python I.E "python youtube_live_listener.py" and input the youtube live id when prompted
	3. The Core Chat Overlay will automatically connect!






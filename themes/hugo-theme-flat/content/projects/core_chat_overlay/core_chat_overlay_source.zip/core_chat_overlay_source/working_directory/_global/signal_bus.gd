extends Node


@warning_ignore_start("unused_signal")
signal authorization_url_ready(new_auth_url: String)
signal twitch_bot_authenticated
signal twitch_bot_not_configured

# INFO Used for latest message display window
signal latest_message_received(chat_name: String, chat_color: Color, chat_message: TwitchChatMessage, loader: TwitchMediaLoader)

signal youtube_live_connected
signal youtube_live_message_received(new_message: String)


signal archive_mode_activated

extends Window

@onready var latest_username_label = %UsernameLabel
@onready var latest_message_label: MessageLabel = %MessageTextLabel

@export var emote_scale: float = 1.0

@onready var latest_message_holder = %LatestMessageHolder


# Called when the node enters the scene tree for the first time.
func _ready():
	SignalBus.latest_message_received.connect(_on_latest_message_received)

func _on_latest_message_received(chat_name: String, chat_color: Color, chat_message: TwitchChatMessage, loader: TwitchMediaLoader):
	var fade_out_tween = create_tween()
	fade_out_tween.tween_property(latest_message_holder,"modulate", Color.TRANSPARENT, 0.10).from(Color.WHITE)
	await fade_out_tween.finished

	latest_username_label.text = chat_name
	latest_username_label["theme_override_colors/font_color"] = chat_color

	await _display_message_instant(chat_message, loader)
	var fade_in_tween = create_tween()
	fade_in_tween.tween_property(latest_message_holder,"modulate", Color.WHITE, 0.25).from(Color.TRANSPARENT)


func _display_message_instant(chat_message: TwitchChatMessage, loader: TwitchMediaLoader):
	latest_message_label.clear_all()

	if !chat_message:
		return

	await chat_message.load_emotes_from_fragment(loader)

	for fragment in chat_message.message.fragments:
		match fragment.type:
			TwitchChatMessage.FragmentType.text:
				latest_message_label.append_text(
					HelperMethods.sanitize_links(fragment.text)
				)

			TwitchChatMessage.FragmentType.mention:
				latest_message_label.append_text(
					"@" + fragment.mention.user_name
				)

			TwitchChatMessage.FragmentType.emote:
				var sprite_frames: SpriteFrames = await fragment.emote.get_sprite_frames(
					loader,
					emote_scale
				)

				var emote_control := EmoteControl.new()
				emote_control.frames = sprite_frames
				emote_control.emote_scale = float(emote_scale)
				emote_control.modulate.a = 1.0

				latest_message_label.append_emote(emote_control)
				emote_control.call_deferred("restart")

	latest_message_label.finalize()

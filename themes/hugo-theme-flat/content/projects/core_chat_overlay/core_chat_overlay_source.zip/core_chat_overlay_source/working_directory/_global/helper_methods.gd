extends Node
class_name HelperMethods

static var LINK_REGEX := RegEx.new()
static var _compiled := false


static func get_all_children(in_node,arr:=[]):
	arr.push_back(in_node)
	for child in in_node.get_children():
		arr = get_all_children(child,arr)
	return arr


# Test out profile image fetching by using random users
static func debug_get_random_twitch_user(twitch_service: TwitchService) -> TwitchUser:
	#var random_username_list = ["squishy0ne5625", "tophat_407", "trashben", "blingmoneypng", "ndbucket", "nnichael_", "pca_littlespoon"]
	var random_username_list = ["squishy0ne5625", "tophat_407"]
	return await twitch_service.get_user(random_username_list.pick_random())


static func sanitize_links(text: String) -> String:
	if not _compiled:
		# What the heck is even Regex? How in world is anyone supposed to understand this junk? This stuff is dark magic and needs to be banned
		LINK_REGEX.compile(r"(?i)(?<!@)\b(?:(?:https?://|www\.)[^\s<>()\[\]{}\"']+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/[^\s<>()\[\]{}\"']*)?)")
		_compiled = true
	return LINK_REGEX.sub(text, "LINK", true)

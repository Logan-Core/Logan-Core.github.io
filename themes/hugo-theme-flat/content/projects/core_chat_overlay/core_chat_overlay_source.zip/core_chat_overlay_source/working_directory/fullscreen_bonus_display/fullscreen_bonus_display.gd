extends Window


# INFO
# Purpose of this scene is to display somethign over the entire stream as a custom overlay/game scene
# A grid-like animation shoudl play to cover up the entire screen. when activated. Purely visual thing. Hide everything behind it



# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass
